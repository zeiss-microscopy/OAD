"""Typed acquisition metadata extracted from a ZEN experiment."""

from __future__ import annotations

from dataclasses import dataclass, replace
from pathlib import Path
from typing import TYPE_CHECKING

from zen_api_utils.compatibility import api_capabilities
from zen_api_utils.extract_czexp_plan import (
    Position,
    extract_plan,
    extract_plan_xml,
    positions_from_plan,
)

if TYPE_CHECKING:
    from zen_api.acquisition.v1beta import ExperimentServiceStub


@dataclass(frozen=True)
class AcquisitionDimensions:
    """Acquisition axes known before pixel streaming starts."""

    time_points: int
    channels: int
    z_planes: int
    scenes: int
    z_spacing: float = 1.0
    tiles: int = 1
    pixel_width: int | None = None
    pixel_height: int | None = None


@dataclass(frozen=True)
class AcquisitionChannel:
    """An active acquisition channel."""

    name: str | None
    pixel_type: str | None


@dataclass(frozen=True)
class ExperimentAcquisition:
    """Small typed snapshot of the acquisition settings used by streaming."""

    experiment_name: str | None
    dimensions: AcquisitionDimensions
    channels_info: tuple[AcquisitionChannel, ...]
    positions: tuple[Position, ...]
    split_scenes_in_separate_files: bool

    @property
    def well_ids(self) -> tuple[str, ...]:
        """Unique sample-carrier well IDs in acquisition order."""
        return tuple(dict.fromkeys(position.well_id for position in self.positions if position.well_id))

    @property
    def well_count(self) -> int:
        """Number of sample-carrier wells used for acquisition."""
        return len(self.well_ids)

    @property
    def position_count(self) -> int:
        """Number of active acquisition positions/scenes."""
        return len(self.positions)

    @classmethod
    def from_plan(cls, plan: dict[str, object], block_index: int = 0) -> ExperimentAcquisition:
        blocks = plan.get("acquisition_blocks")
        if not isinstance(blocks, list) or not blocks:
            raise ValueError("The experiment contains no active acquisition blocks.")
        if not 0 <= block_index < len(blocks):
            raise ValueError(f"Active acquisition block {block_index} is not available.")
        block = blocks[block_index]
        if not isinstance(block, dict):
            raise TypeError("The acquisition block has an invalid structure.")

        dimensions = block.get("dimensions")
        if not isinstance(dimensions, dict):
            raise TypeError("The acquisition block has no dimensions.")
        channels = block.get("channels", [])
        positions = block.get("positions", [])
        if not isinstance(channels, list) or not isinstance(positions, list):
            raise TypeError("The acquisition block has invalid channel or position data.")

        source = plan.get("source")
        experiment_name = None
        if isinstance(source, dict):
            source_path = source.get("path")
            if isinstance(source_path, str):
                experiment_name = Path(source_path).stem.removesuffix(".czexp")

        return cls(
            experiment_name=experiment_name,
            dimensions=AcquisitionDimensions(
                time_points=int(dimensions.get("T", 1) or 1),
                channels=int(dimensions.get("C", 1) or 1),
                z_planes=int(dimensions.get("Z", 1) or 1),
                scenes=int(dimensions.get("S", 1) or 1),
                z_spacing=float(dimensions.get("ZSpacing", 1.0) or 1.0),
                tiles=int(dimensions.get("M", 1) or 1),
                pixel_width=_optional_int(dimensions.get("X")),
                pixel_height=_optional_int(dimensions.get("Y")),
            ),
            channels_info=tuple(
                AcquisitionChannel(
                    name=channel.get("name") if isinstance(channel.get("name"), str) else None,
                    pixel_type=channel.get("pixel_type") if isinstance(channel.get("pixel_type"), str) else None,
                )
                for channel in channels
                if isinstance(channel, dict)
            ),
            positions=tuple(positions_from_plan(plan, block_index=block_index)),
            split_scenes_in_separate_files=bool(block.get("split_scenes_in_separate_files", False)),
        )

    @classmethod
    def from_czexp(cls, source: str | Path) -> ExperimentAcquisition:
        """Read a CZEXP once, including typed positions and region metadata."""
        return cls.from_plan(extract_plan(source))

    @classmethod
    def from_xml(cls, xml: str, source_name: str = "<experiment-export>") -> ExperimentAcquisition:
        """Parse an API XML export through the same parser as persisted experiments."""
        return cls.from_plan(extract_plan_xml(xml, source_name))


async def query_experiment_acquisition(
    service: ExperimentServiceStub,
    experiment_id: str,
    experiment_name: str | None = None,
) -> ExperimentAcquisition:
    """Export and parse a loaded experiment through the ZEN API."""
    with api_capabilities("Experiment XML export", service, methods=("export",)):
        from zen_api.acquisition.v1beta import ExperimentServiceExportRequest

        with api_capabilities("Experiment XML export", ExperimentServiceExportRequest, members=("experiment_id",)):
            response = await service.export(ExperimentServiceExportRequest(experiment_id=experiment_id))
    with api_capabilities("Experiment XML export response", response, members=("xml",)):
        xml = response.xml
    if not isinstance(xml, str) or not xml.strip():
        raise ValueError("ZEN returned an empty experiment XML export.")
    acquisition = ExperimentAcquisition.from_xml(xml, experiment_name or experiment_id)
    if experiment_name is None:
        return acquisition
    return replace(acquisition, experiment_name=experiment_name)


async def load_experiment_acquisition(
    service: ExperimentServiceStub,
    experiment_name: str,
) -> ExperimentAcquisition:
    """Load an experiment by name, export it, and return its acquisition data."""
    from .experiment import load_experiment

    experiment_id = await load_experiment(service, experiment_name)
    return await query_experiment_acquisition(service, experiment_id, experiment_name)


def _optional_int(value: object) -> int | None:
    return value if isinstance(value, int) else None
