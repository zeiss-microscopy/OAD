#################################################################
# File        : zen_omezarr.py
# Institution : Carl Zeiss Microscopy GmbH
#
# Utility functions for the ZEN-API OME-ZARR streaming workflow:
#   - ExperimentConfig dataclass & INI parser
#   - start_experiment() helper (ZEN-API experiment control)
#   - build_progress_bar() for console progress display
#   - open_in_ndv_viewer() / open_in_napari_viewer() for viewing
#   - read_omezarr_axis_names() for OME-ZARR 0.5 metadata
#
# Copyright(c) 2026 Carl Zeiss AG, Germany. All Rights Reserved.
#
# Permission is granted to use, modify and distribute this code,
# as long as this copyright notice remains part of the code.
#################################################################

import configparser
import json
import logging
from dataclasses import dataclass
from pathlib import Path
from typing import Any

# ZEN API auto-generated stubs
from zen_api_utils.compatibility import api_capabilities, api_operation

with api_capabilities("OME-Zarr acquisition"):
    from zen_api.acquisition.v1beta import (
        ExperimentServiceGetImageOutputPathRequest,
        ExperimentServiceLoadRequest,
        ExperimentServiceStartExperimentRequest,
        ExperimentServiceStub,
    )

from zen_api_utils.misc import initialize_zenapi

logger = logging.getLogger(__name__)


@dataclass
class ExperimentConfig:
    """Parsed experiment configuration."""

    experiment_name: str
    czi_name: str
    start_from_script: bool
    overwrite_czi: bool
    # dimensions
    time_points: int
    channels: int
    z_planes: int
    z_spacing: float
    tiles: int
    scenes: int
    # output
    output_dir: str
    dtype: str
    compression: str | None
    overwrite_zarr: bool
    # stream
    channel_index: int | None
    # zenapi
    zenapi_config: str
    # optional ZEN XML scene-to-well metadata for OME-ZARR HCS output
    positions: tuple[dict[str, object], ...] = ()
    use_hcs_layout: bool = True
    keep_source_tiles: bool = False
    # number of chunks per spatial shard; None disables Zarr v3 sharding
    spatial_shard_size_chunks: int | None = 2
    max_pending_frames: int = 4096


def load_experiment_config(config_path: str | Path) -> ExperimentConfig:
    """Load experiment configuration from an INI file.

    Args:
        config_path: Path to the experiment config INI file.

    Returns:
        Populated ExperimentConfig dataclass.
    """
    config_path = Path(config_path).resolve()
    if not config_path.exists():
        raise FileNotFoundError(f"Experiment config not found: {config_path}")

    cfg = configparser.ConfigParser()
    cfg.read(config_path)

    # zenapi config: if empty, fall back to config.ini next to the script
    zenapi_config = cfg.get("zenapi", "config", fallback="").strip()
    if not zenapi_config:
        zenapi_config = str(Path(__file__).parent / "config.ini")

    # channel index: empty string means None (all channels)
    ch_idx_raw = cfg.get("stream", "channel_index", fallback="").strip()
    channel_index = int(ch_idx_raw) if ch_idx_raw else None

    # compression: 'none' string -> None
    compression_raw = cfg.get("output", "compression", fallback="blosc-zstd").strip()
    compression = compression_raw if compression_raw != "none" else None

    shard_size_raw = cfg.get("output", "spatial_shard_size_chunks", fallback="2").strip().lower()
    spatial_shard_size_chunks = None if shard_size_raw in {"", "0", "none"} else int(shard_size_raw)
    if spatial_shard_size_chunks is not None and spatial_shard_size_chunks < 1:
        raise ValueError("spatial_shard_size_chunks must be a positive integer, 0, or none")
    max_pending_frames = cfg.getint(
        "stream",
        "max_pending_frames",
        fallback=4096,
    )
    if max_pending_frames < 1:
        raise ValueError("max_pending_frames must be a positive integer")

    return ExperimentConfig(
        experiment_name=cfg.get("experiment", "name"),
        czi_name=cfg.get("experiment", "czi_name", fallback="zenapi_stream"),
        start_from_script=cfg.getboolean("experiment", "start_from_script", fallback=False),
        overwrite_czi=cfg.getboolean("experiment", "overwrite_czi", fallback=True),
        time_points=cfg.getint("dimensions", "time_points", fallback=1),
        channels=cfg.getint("dimensions", "channels", fallback=1),
        z_planes=cfg.getint("dimensions", "z_planes", fallback=1),
        z_spacing=cfg.getfloat("dimensions", "z_spacing", fallback=1.0),
        tiles=cfg.getint("dimensions", "tiles", fallback=1),
        scenes=cfg.getint("dimensions", "scenes", fallback=1),
        output_dir=cfg.get("output", "directory", fallback="."),
        dtype=cfg.get("output", "dtype", fallback="uint16"),
        compression=compression,
        overwrite_zarr=cfg.getboolean("output", "overwrite", fallback=True),
        channel_index=channel_index,
        zenapi_config=zenapi_config,
        use_hcs_layout=cfg.getboolean(
            "output",
            "use_hcs_layout",
            fallback=True,
        ),
        keep_source_tiles=cfg.getboolean(
            "output",
            "keep_source_tiles",
            fallback=False,
        ),
        spatial_shard_size_chunks=spatial_shard_size_chunks,
        max_pending_frames=max_pending_frames,
    )


@api_operation("Experiment startup", ExperimentServiceStub, methods=("load", "get_image_output_path", "start_experiment"))
async def start_experiment(
    exp_name: str,
    czi_name: str,
    overwrite: bool = False,
    zenapi_config: str | Path = "config.ini",
) -> tuple[str, Path]:
    """Start a ZEN experiment via the ZEN-API.

    Args:
        exp_name: Experiment name (without .czexp extension).
        czi_name: Desired CZI output name (without .czi extension).
        overwrite: Allow overwriting an existing CZI.
        zenapi_config: Path to the ZEN-API config file.

    Returns:
        Tuple of (experiment_id, czi_path).
    """
    channel, metadata = initialize_zenapi(zenapi_config)
    try:
        exp_service = ExperimentServiceStub(channel=channel, metadata=metadata)
        my_exp = await exp_service.load(ExperimentServiceLoadRequest(experiment_name=exp_name))
        logger.info(f"Loaded experiment: {exp_name} (id={my_exp.experiment_id})")
        czi_path = await start_loaded_experiment(exp_service, my_exp.experiment_id, czi_name, overwrite)
        return my_exp.experiment_id, czi_path
    finally:
        channel.close()


@api_operation("Experiment startup", ExperimentServiceStub, methods=("get_image_output_path", "start_experiment"))
async def start_loaded_experiment(
    service: ExperimentServiceStub,
    experiment_id: str,
    czi_name: str,
    overwrite: bool = False,
) -> Path:
    """Start an already loaded experiment without changing its identity.

    Args:
        service: Connected ZEN experiment service.
        experiment_id: ID obtained before arming pixel subscriptions.
        czi_name: Output name without the CZI extension.
        overwrite: Allow replacement of an existing CZI file.

    Returns:
        Path to the experiment's CZI output.
    """
    save_path = await service.get_image_output_path(ExperimentServiceGetImageOutputPathRequest())
    czi_path = Path(save_path.image_output_path) / f"{czi_name}.czi"
    if czi_path.exists():
        if not overwrite:
            raise FileExistsError(f"CZI file already exists: {czi_path}")
        czi_path.unlink()
    await service.start_experiment(
        ExperimentServiceStartExperimentRequest(
            experiment_id=experiment_id,
            output_name=czi_name,
        )
    )
    logger.info("Experiment execution started: %s", experiment_id)
    return czi_path


def build_progress_bar(current: int, total: int | None, width: int = 40) -> str:
    """Render a text progress bar string.

    Args:
        current: Current frame number (1-based).
        total: Total expected frames, or None if unknown.
        width: Character width of the bar.

    Returns:
        Formatted progress bar string.
    """
    if total is not None and total > 0:
        frac = min(current / total, 1.0)
        filled = int(width * frac)
        bar = "#" * filled + "-" * (width - filled)
        return f"\r  [{bar}] {current}/{total} frames ({frac*100:.1f}%)"
    else:
        # unknown total – show a spinner-style counter
        return f"\r  Frames written: {current}"


def open_in_ndv_viewer(zarr_path: Path) -> None:
    """Open an OME-ZARR dataset in the ndv viewer.

    Reads axis names (T, C, Z, Y, X) and per-axis scales from the OME-ZARR
    0.5 metadata stored in ``zarr.json`` and wraps the highest-resolution
    array as a dask-backed ``xr.DataArray`` with physically-spaced
    coordinates so that ndv shows correct proportions (including Z depth)
    and labelled sliders.

    Requires optional dependencies: ``ndv``, ``zarr``, ``dask``, ``xarray``.
    If any are missing the function logs a warning and returns silently.

    Args:
        zarr_path: Path to the ``.ome.zarr`` directory.
    """
    try:
        import dask.array as da
        import zarr
        import ndv
        import numpy as np
        import xarray as xr
    except ImportError as e:
        logger.warning(
            f"Cannot open viewer (missing dependency: {e}). " "Install with: pip install ndv zarr dask xarray"
        )
        return

    try:
        logger.info(f"Opening OME-ZARR in ndv viewer: {zarr_path}")
        image_metadata = _read_first_image_metadata(zarr_path)
        if image_metadata is None:
            logger.error("No OME-ZARR multiscale image metadata found.")
            return
        image_path, _ = image_metadata
        zarr_group = zarr.open(str(image_path), mode="r")

        # OME-ZARR stores the image array under the "0" key (highest resolution).
        # zarr.open() returns Array | Group; subscripting a Group with a string
        # key returns a broad union. We narrow to Array here.
        zarr_arr: zarr.Array = zarr_group["0"]  # type: ignore[index,assignment]
        if not hasattr(zarr_arr, "shape"):
            logger.error("Expected a zarr Array at key '0', got: %s", type(zarr_arr).__name__)
            return
        logger.info(f"Array shape: {zarr_arr.shape}, dtype: {zarr_arr.dtype}")

        # Read axis names from OME-ZARR 0.5 metadata (zarr v3: zarr.json).
        # ome-writers 0.3+ stores multiscales under attributes.ome.multiscales
        axis_names = read_omezarr_axis_names(zarr_path)
        axis_scales = read_omezarr_axis_scales(zarr_path)

        if axis_names and len(axis_names) == len(zarr_arr.shape):
            # Wrap zarr v3 array with dask for lazy chunk-aware loading,
            # then label dimensions via xarray for the ndv viewer.
            # Use physical coordinates (index * scale) so that the viewer
            # renders the correct aspect ratio, especially for Z stacks
            # where the z-spacing typically differs from the XY pixel size.
            dask_arr = da.from_array(zarr_arr, chunks=zarr_arr.chunks)  # type: ignore[arg-type]
            coords = {}
            for name, size in zip(axis_names, zarr_arr.shape):
                scale = axis_scales.get(name, 1.0) if axis_scales else 1.0
                coords[name] = np.arange(size, dtype=np.float64) * scale
            data = xr.DataArray(dask_arr, dims=axis_names, coords=coords)
            logger.info(f"Viewer data: shape={data.shape}, dims={data.dims}")
            if axis_scales:
                logger.info(f"Applied axis scales: {axis_scales}")
            ndv.imshow(data)
        else:
            logger.warning("Could not read axis names from OME-ZARR metadata, showing without labels.")
            ndv.imshow(zarr_arr)
    except Exception as e:
        logger.error(f"Failed to open OME-ZARR in ndv viewer: {e}")


def open_in_napari_viewer(zarr_path: Path) -> None:
    """Open an OME-ZARR dataset in the napari viewer.

    Uses the ``napari-ome-zarr`` plugin to read the dataset with full
    OME-ZARR metadata support (channels, scales, axis labels).

    Requires optional dependencies: ``napari`` and ``napari-ome-zarr``.
    If any are missing the function logs a warning and returns silently.

    Args:
        zarr_path: Path to the ``.ome.zarr`` directory.
    """
    try:
        import napari  # noqa: F811
    except ImportError as e:
        logger.warning(f"Cannot open napari viewer (missing dependency: {e}). " "Install with: pip install napari[all]")
        return

    try:
        import napari_ome_zarr  # noqa: F401

        del napari_ome_zarr
    except ImportError as e:
        logger.warning(f"Cannot open napari viewer (missing plugin: {e}). " "Install with: pip install napari-ome-zarr")
        return

    try:
        logger.info(f"Opening OME-ZARR in napari viewer: {zarr_path}")
        viewer = napari.Viewer()
        viewer.open(str(zarr_path), plugin="napari-ome-zarr")
        logger.info("napari viewer opened successfully.")
        napari.run()
    except Exception as e:
        logger.error(f"Failed to open OME-ZARR in napari viewer: {e}")


def read_omezarr_axis_names(zarr_path: Path) -> tuple[str, ...] | None:
    """Read axis names from the first OME-ZARR 0.5 image metadata.

    OME-ZARR 0.5 (zarr v3) stores the multiscales metadata inside
    ``zarr.json → attributes.ome.multiscales``, unlike OME-ZARR 0.4
    which used ``.zattrs``.

    Args:
        zarr_path: Path to the ``.ome.zarr`` directory.

    Returns:
        Tuple of uppercase axis names (e.g. ``('T', 'C', 'Z', 'Y', 'X')``),
        or ``None`` if the metadata cannot be read.
    """
    image_metadata = _read_first_image_metadata(zarr_path)
    if image_metadata is None:
        return None

    _, root_meta = image_metadata

    multiscales = root_meta.get("attributes", {}).get("ome", {}).get("multiscales", [])
    if not isinstance(multiscales, list) or not multiscales:
        return None

    first_multiscale = multiscales[0]
    if not isinstance(first_multiscale, dict):
        return None
    axes = first_multiscale.get("axes", [])
    if not axes:
        return None

    try:
        axis_names = tuple(str(axis["name"]).upper() for axis in axes)
    except (KeyError, TypeError):
        return None
    logger.info(f"OME-ZARR axis names: {axis_names}")
    return axis_names


def read_omezarr_axis_scales(zarr_path: Path) -> dict[str, float] | None:
    """Read scale factors from the first OME-ZARR 0.5 image metadata.

    The scale transform is stored in
    ``zarr.json → attributes.ome.multiscales[0].datasets[0].coordinateTransformations``
    as a list entry with ``{"type": "scale", "scale": [s0, s1, ...]}``.
    The scale values are ordered to match the axes list.

    Args:
        zarr_path: Path to the ``.ome.zarr`` directory.

    Returns:
        Dict mapping uppercase axis name to its scale factor,
        or ``None`` if the metadata cannot be read.
    """
    image_metadata = _read_first_image_metadata(zarr_path)
    if image_metadata is None:
        return None

    _, root_meta = image_metadata

    multiscales = root_meta.get("attributes", {}).get("ome", {}).get("multiscales", [])
    if not isinstance(multiscales, list) or not multiscales:
        return None

    first_multiscale = multiscales[0]
    if not isinstance(first_multiscale, dict):
        return None
    axes = first_multiscale.get("axes", [])
    datasets = first_multiscale.get("datasets", [])
    if not axes or not datasets:
        return None

    # Find the scale transform for the highest-resolution dataset (index 0)
    transforms = datasets[0].get("coordinateTransformations", [])
    scale_values = None
    for t in transforms:
        if t.get("type") == "scale":
            scale_values = t.get("scale")
            break

    if scale_values is None or len(scale_values) != len(axes):
        return None

    try:
        axis_scales = {str(axis["name"]).upper(): float(scale) for axis, scale in zip(axes, scale_values)}
    except (KeyError, TypeError, ValueError):
        return None
    logger.info(f"OME-ZARR axis scales: {axis_scales}")
    return axis_scales


def _read_first_image_metadata(
    zarr_path: Path,
) -> tuple[Path, dict[str, Any]] | None:
    """Return metadata for the root or first descendant multiscale image."""
    root_metadata = zarr_path / "zarr.json"
    candidates = [root_metadata]
    if zarr_path.exists():
        candidates.extend(path for path in sorted(zarr_path.rglob("zarr.json")) if path != root_metadata)

    for metadata_path in candidates:
        try:
            with metadata_path.open(encoding="utf-8") as metadata_file:
                metadata = json.load(metadata_file)
        except (OSError, json.JSONDecodeError):
            continue
        if not isinstance(metadata, dict):
            continue
        attributes = metadata.get("attributes")
        if not isinstance(attributes, dict):
            continue
        ome = attributes.get("ome")
        if not isinstance(ome, dict):
            continue
        multiscales = ome.get("multiscales")
        if multiscales:
            return metadata_path.parent, metadata
    return None


def find_image_paths(zarr_path: str | Path) -> list[Path]:
    """Find regular or HCS image groups containing multiscales metadata."""
    import zarr

    zarr_path = Path(zarr_path)
    root = zarr.open_group(zarr_path, mode="r")
    if "OME" in root:
        ome_metadata = root["OME"].attrs.get("ome", {})
        series = ome_metadata.get("series", []) if isinstance(ome_metadata, dict) else []
        if isinstance(series, list) and series:
            return [zarr_path / path for path in series if isinstance(path, str)]

    image_paths: list[Path] = []

    def visit(group: Any, group_path: Path) -> None:
        ome_metadata = group.attrs.get("ome", {})
        if isinstance(ome_metadata, dict) and isinstance(ome_metadata.get("multiscales"), list):
            image_paths.append(group_path)
            return
        for name, subgroup in group.groups():
            visit(subgroup, group_path / name)

    visit(root, zarr_path)
    return image_paths


def generate_pyramids(
    zarr_path: str | Path,
    pyramid_levels: int,
    spatial_shard_size_chunks: int | None = 2,
) -> None:
    """Append Y/X pyramid levels without rewriting level 0."""
    if pyramid_levels < 1:
        raise ValueError("pyramid_levels must be at least 1")

    import ngff_zarr as nz

    image_paths = find_image_paths(zarr_path)
    if not image_paths:
        raise RuntimeError(f"No OME-Zarr image groups found in: {zarr_path}")

    chunks_per_shard = (
        {"y": spatial_shard_size_chunks, "x": spatial_shard_size_chunks}
        if spatial_shard_size_chunks is not None
        else None
    )

    logger.info(
        "Generating %s pyramid level(s) for %s image(s) ...",
        pyramid_levels,
        len(image_paths),
    )
    for image_index, image_path in enumerate(image_paths, start=1):
        existing = nz.from_ngff_zarr(image_path, validate=True)
        base_image = existing.images[0]
        if not {"y", "x"}.issubset(base_image.dims):
            raise RuntimeError(f"OME-Zarr image has no Y/X axes: {image_path}")

        spatial_dims = [dim for dim in base_image.dims if dim in {"z", "y", "x"}]
        scale_factors = [
            {dim: 2**level if dim in {"y", "x"} else 1 for dim in spatial_dims}
            for level in range(1, pyramid_levels + 1)
        ]
        multiscales = nz.to_multiscales(
            base_image,
            scale_factors=scale_factors,
            method=nz.Methods.ITKWASM_GAUSSIAN,
            chunks=tuple(int(chunk) for chunk in base_image.data.chunksize),
            cache=True,
        )
        for level, dataset in enumerate(multiscales.metadata.datasets):
            dataset.path = str(level)

        # start_level=1 reuses level 0; sharding applies only to new levels.
        nz.to_ome_zarr(
            image_path,
            multiscales,
            version="0.5",
            overwrite=False,
            start_level=1,
            chunks_per_shard=chunks_per_shard,
        )
        logger.info(
            "Pyramid image %s/%s complete: %s",
            image_index,
            len(image_paths),
            image_path,
        )
    logger.info("OME-Zarr pyramid generation completed: %s", zarr_path)
