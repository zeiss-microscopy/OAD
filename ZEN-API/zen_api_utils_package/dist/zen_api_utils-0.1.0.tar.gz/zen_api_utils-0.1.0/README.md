# zen_api_utils

Reusable, headless helpers for applications built on the generated `zen_api`
protobuf and gRPC package.

## Scope

- ZEN API connection and logging helpers
- Experiment metadata and CZEXP acquisition-plan parsing
- Camera, changer, filter, objective, and stage helpers
- Sample-carrier and tile-position models
- Workflow service helpers
- Legacy TCP/IP control helpers
- Headless scene geometry primitives

This package contains application-side utilities and is separate from the
generated `zen_api` package. OME-Zarr support is included under
`zen_api_utils.streaming.pipeline` and `zen_api_utils.streaming.omezarr` and is
optional.

## Installation

Install a generated `zen_api` wheel first, then install this package:

```powershell
pip install .
```

For OME-Zarr output and post-processing:

```powershell
pip install ".[omezarr]"
```

For development:

```powershell
pip install ".[dev]"
```

## Build distributions

From the repository root, run:

```powershell
.\zen_api_utils_package\build_package.ps1
```

The wheel and source distribution are written to
`zen_api_utils_package\dist`.

To build the local generated `zen_api` package, install it, and run the
utility package tests as well:

```powershell
.\zen_api_utils_package\build_package.ps1 -Test
```

The test mode uses a `zen_api` package directory under `python_packages` and
does not require `zen_api` to be published on PyPI.

To install all optional dependencies:

```powershell
pip install ".[all]"
```

## Migration

The examples now use this package directly, while the established root module
names remain available for the general-purpose utilities:

```python
from zen_api_utils.experiment_acquisition import ExperimentAcquisition
from zen_api_utils.misc import initialize_zenapi
from zen_api_utils.streaming import decode_pixel_payload
from zen_api_utils.streaming.pipeline import stream_to_omezarr_with_config
```

Streaming and OME-Zarr helpers live under the `streaming` subpackage so they
share the same acquisition and connection utilities without requiring a
second distribution.

The reusable streaming pipeline is also available as a console command after
installation:

```powershell
zenapi-stream2omezarr --help
```
