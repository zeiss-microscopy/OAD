param(
    [switch]$Test,
    [string]$ZenApiPackagePath
)

$ErrorActionPreference = "Stop"

$packageRoot = $PSScriptRoot
$repositoryRoot = Split-Path -Parent $packageRoot
$distPath = Join-Path $packageRoot "dist"
$docsPath = Join-Path $packageRoot "docs"
$localBuildRoot = Join-Path $repositoryRoot ".build"

function Invoke-Python {
    param(
        [Parameter(Mandatory = $true)]
        [string[]]$Arguments
    )

    & python @Arguments | Out-Host
    if ($LASTEXITCODE -ne 0) {
        throw "Python command failed with exit code ${LASTEXITCODE}: python $($Arguments -join ' ')"
    }
}

function Get-LatestZenApiPackagePath {
    $packageCandidates = Get-ChildItem -Path (Join-Path $repositoryRoot "python_packages") -Directory |
        Where-Object {
            $_.Name -like "zen_api-*" -and
            (Test-Path (Join-Path $_.FullName "pyproject.toml")) -and
            (Test-Path (Join-Path $_.FullName "src\zen_api"))
        } |
        Sort-Object Name -Descending

    if ($null -eq $packageCandidates -or $packageCandidates.Count -eq 0) {
        throw "No generated zen_api package with pyproject.toml was found under python_packages."
    }

    return $packageCandidates[0].FullName
}

function Build-LocalZenApiWheel {
    param(
        [Parameter(Mandatory = $true)]
        [string]$SourcePath
    )

    $zenApiBuildPath = Join-Path $localBuildRoot "zen_api"
    if (Test-Path $zenApiBuildPath) {
        Remove-Item -Path $zenApiBuildPath -Recurse -Force
    }
    New-Item -ItemType Directory -Path $zenApiBuildPath -Force | Out-Null

    Push-Location $SourcePath
    try {
        Invoke-Python @("-m", "build", "--wheel", "--outdir", $zenApiBuildPath)
    }
    finally {
        Pop-Location
    }

    $wheel = Get-ChildItem -Path $zenApiBuildPath -Filter "zen_api-*.whl" -File |
        Select-Object -First 1
    if ($null -eq $wheel) {
        throw "The local zen_api wheel was not created."
    }

    return $wheel.FullName
}

function Get-PackageVersion {
    $versionLine = Select-String -Path (Join-Path $packageRoot "pyproject.toml") -Pattern '^version\s*=\s*"([^"]+)"'
    if ($null -eq $versionLine) {
        throw "Package version was not found in pyproject.toml."
    }

    return $versionLine.Matches[0].Groups[1].Value
}

function Build-Documentation {
    $zenApiPackagePath = Get-LatestZenApiPackagePath
    $zenApiSourcePath = Join-Path $zenApiPackagePath "src"
    $packageSourcePath = Join-Path $packageRoot "src"
    $generatorPath = Join-Path $repositoryRoot "packaging\generate_mkdocs_pages.py"
    $packagingPath = Join-Path $repositoryRoot "packaging"
    $staticDocsPath = Join-Path $packageRoot "mkdocs_docs"
    $configPath = Join-Path $docsPath "mkdocs_generated.yml"
    $version = Get-PackageVersion

    if (-not (Test-Path $generatorPath)) {
        throw "MkDocs page generator was not found: $generatorPath"
    }
    if (-not (Test-Path $staticDocsPath)) {
        throw "Utility package static docs were not found: $staticDocsPath"
    }

    $originalPythonPath = $env:PYTHONPATH
    $env:PYTHONPATH = @($packageSourcePath, $zenApiSourcePath) -join [IO.Path]::PathSeparator
    try {
        Invoke-Python @(
            $generatorPath,
            "--src_path", $packageSourcePath,
            "--packaging_path", $packagingPath,
            "--output_path", $packageRoot,
            "--version", $version,
            "--package_name", "zen_api_utils",
            "--include_modules",
            "--site_name", "ZEN API Utilities",
            "--static_docs_path", $staticDocsPath
        )

        Invoke-Python @(
            "-m", "mkdocs", "build",
            "--config-file", $configPath,
            "--strict"
        )
    }
    finally {
        $env:PYTHONPATH = $originalPythonPath
    }
}

if ($Test) {
    if ([string]::IsNullOrWhiteSpace($ZenApiPackagePath)) {
        $ZenApiPackagePath = Get-LatestZenApiPackagePath
    }
    elseif (-not (Test-Path (Join-Path $ZenApiPackagePath "pyproject.toml"))) {
        throw "The supplied zen_api package path is invalid: $ZenApiPackagePath"
    }

    Write-Host "Building local zen_api dependency from: $ZenApiPackagePath"
    $zenApiWheelPath = Build-LocalZenApiWheel -SourcePath $ZenApiPackagePath
    Invoke-Python @("-m", "pip", "install", "--force-reinstall", $zenApiWheelPath)
}

if (Test-Path $distPath) {
    Remove-Item -Path $distPath -Recurse -Force
}

Push-Location $packageRoot
try {
    Invoke-Python @("-m", "build")
    Invoke-Python @("-m", "twine", "check", (Join-Path $distPath "*.whl"), (Join-Path $distPath "*.tar.gz"))
    Build-Documentation

    if ($Test) {
        Invoke-Python @("-m", "pip", "install", "--no-deps", "-e", ".[dev]")
        Invoke-Python @("-m", "pytest")
    }
}
finally {
    Pop-Location
}

Write-Host "Distributions created in $distPath"
Get-ChildItem -Path $distPath -File | Select-Object -ExpandProperty Name