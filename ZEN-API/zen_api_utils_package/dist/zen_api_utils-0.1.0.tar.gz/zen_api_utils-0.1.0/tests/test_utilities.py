from zen_api_utils.extract_czexp_plan import extract_plan_xml
from zen_api_utils.sample_carrier import WellPlate


def test_well_plate_round_trip() -> None:
    plate = WellPlate(8, 12)

    assert plate.well_to_index("B3") == (1, 2)
    assert plate.index_to_well(7, 11) == "H12"
    assert "A1" in plate
    assert "I1" not in plate


def test_extract_plan_xml_reads_active_tile_regions() -> None:
    xml = """
    <Experiment>
      <ExperimentBlocks>
        <AcquisitionBlock IsActivated="true">
          <SubDimensionSetups>
            <RegionsSetup IsActivated="true">
              <SampleHolder>
                <TileRegions>
                  <TileRegion Name="B2">
                    <CenterPosition>100,200</CenterPosition>
                    <Columns>3</Columns>
                    <Rows>2</Rows>
                    <TemplateShapeId>2-2</TemplateShapeId>
                    <IsUsedForAcquisition>true</IsUsedForAcquisition>
                  </TileRegion>
                </TileRegions>
              </SampleHolder>
            </RegionsSetup>
          </SubDimensionSetups>
        </AcquisitionBlock>
      </ExperimentBlocks>
    </Experiment>
    """

    plan = extract_plan_xml(xml)
    block = plan["acquisition_blocks"][0]

    assert block["dimensions"]["S"] == 1
    assert block["dimensions"]["M"] == 6
    assert block["positions"][0]["well_id"] == "B2"


def test_extract_plan_xml_reads_direct_single_tile_regions_without_inventing_wells() -> None:
    xml = """
    <Experiment>
      <ExperimentBlocks>
        <AcquisitionBlock IsActivated="true">
          <SubDimensionSetups>
            <RegionsSetup IsActivated="true">
              <SampleHolder>
                <SingleTileRegions>
                  <SingleTileRegion Name="P1" Id="1">
                    <X>30080.21</X><Y>24661.814</Y><Z>-8000</Z>
                    <IsUsedForAcquisition>true</IsUsedForAcquisition>
                  </SingleTileRegion>
                  <SingleTileRegion Name="P2" Id="2">
                    <X>32389.872</X><Y>27671.373</Y><Z>-8000</Z>
                    <IsUsedForAcquisition>true</IsUsedForAcquisition>
                  </SingleTileRegion>
                  <SingleTileRegion Name="P3" Id="3">
                    <IsUsedForAcquisition>false</IsUsedForAcquisition>
                  </SingleTileRegion>
                </SingleTileRegions>
                <SingleTileRegionArrays />
              </SampleHolder>
            </RegionsSetup>
          </SubDimensionSetups>
        </AcquisitionBlock>
      </ExperimentBlocks>
    </Experiment>
    """

    block = extract_plan_xml(xml)["acquisition_blocks"][0]

    assert block["dimensions"]["S"] == 2
    assert block["position_count"] == 2
    assert block["well_count"] == 0
    assert block["positions"][0]["stage_position"] == {"x": 30080.21, "y": 24661.814, "z": -8000.0}
    assert [position["well_id"] for position in block["positions"]] == [None, None]
    assert block["planned_outputs"][0]["well_ids"] == []

    split_block = extract_plan_xml(
        xml.replace("<SampleHolder>", "<SampleHolder><SplitScenesInSeparateFiles>true</SplitScenesInSeparateFiles>")
    )["acquisition_blocks"][0]
    assert [output["suggested_filename"] for output in split_block["planned_outputs"]] == [
        "<experiment-export>-Scene-001-P1.czi",
        "<experiment-export>-Scene-002-P2.czi",
    ]
